package com.example.pr_28;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SwipeLeft extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_swipe_left);
    }
}